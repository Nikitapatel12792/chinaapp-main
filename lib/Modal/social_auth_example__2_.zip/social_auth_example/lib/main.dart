import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:social_auth_example/auth/homepage.dart';

void main() {
  runApp(
    const GetMaterialApp(
      home: HomePage(),
    ),
  );
}
